// Sources/Helpers/String+Identifiable.swift
import Foundation
extension String: Identifiable { public var id: String { self } }
